<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Eva_Api {

	public function __construct()
	{
		ini_set('display_errors', 1);
		error_reporting(-1);
	}

    public function execute_call($sitio = false)
    {
    	$self =& get_instance();

    	$function = $self->uri->segment(2);

    	switch($function){
    		case "eva":
				$self->benchmark->mark('code_start');
				$result = $this->eva_api($sitio);
				$self->benchmark->mark('code_end');
				$this->build_response($result, $function);
				break;
			case "activities":
				$self->benchmark->mark('code_start');
				$result = $this->actividades_api($sitio);
				$self->benchmark->mark('code_end');
				$this->build_response($result, $function);
				break;
			case "files":
				$self->benchmark->mark('code_start');
				$result = $this->archivos_api($sitio);
				$self->benchmark->mark('code_end');
				$this->build_response($result, $function);
				break;
			case "clients":
				$self->benchmark->mark('code_start');
				$result = $this->clientes_api($sitio);
				$self->benchmark->mark('code_end');
				$this->build_response($result, $function);
				break;
			case "commentaries":
				$self->benchmark->mark('code_start');
				$result = $this->comentarios_api($sitio);
				$self->benchmark->mark('code_end');
				$this->build_response($result, $function);
				break;
			case "contacts":
				$self->benchmark->mark('code_start');
				$result = $this->contactos_api($sitio);
				$self->benchmark->mark('code_end');
				$this->build_response($result, $function);
				break;
			case "tareas":
				$self->benchmark->mark('code_start');
				$result = $this->tareas_api($sitio);
				$self->benchmark->mark('code_end');
				$this->build_response($result, $function);
				break;
			case "users":
				$self->benchmark->mark('code_start');
				$result = $this->usuarios_api($sitio);
				$self->benchmark->mark('code_end');
				$this->build_response($result, $function);
				break;
			default:
				echo "Function Error";
				break;
		}


    }

    private function build_response($result,$function){
		$self =& get_instance();

		$response = array();
		$response['status'] = 'OK';
		$response['function'] = $self->uri->segment(2).'/'.$self->uri->segment(3);
		$response['response_time'] = $self->benchmark->elapsed_time('code_start', 'code_end');
		$response['result_count'] = count($result);
		$response['data'] = $result;
	    //Parsear response para colocar headers de columnas
		if( sizeof($response['data'])>0 && (is_array($response['data']) || is_object($response['data'])) && $response['data']!==false ) {
			$response['header_col_names'] = array();
			$storedHeader = array();
			foreach( $response['data'] as $indiceDato => $renglon ) {
				//Para cada renglon, obtener nombres de primera capa de datos
				if( is_array($renglon) ) {
					$renglonObjecto = (object) $renglon;
				} else {
					$renglonObjecto = $renglon;
				}
				if( is_object($renglonObjecto) ) {
					foreach( $renglonObjecto as $indiceCampo => $campo ) {
						if( !in_array($indiceCampo, $storedHeader) && $indiceCampo!='' ) {
							$response['header_col_names'][] = new stdClass;
							$headerCount = sizeof($response['header_col_names'])-1;
							$response['header_col_names'][$headerCount] = new stdClass;
							$response['header_col_names'][$headerCount]->name = $indiceCampo;
							$response['header_col_names'][$headerCount]->label = ucwords(str_replace('_', ' ', $indiceCampo));
							$response['header_col_names'][$headerCount]->order = $headerCount+1;
							$storedHeader[] = $indiceCampo;
						}
					}
				}
			}
		}
	    echo json_encode($response);
    }// end build_response()º

	private function actividades_api($sitio) {
		$self =& get_instance();
	    $self->load->model('../../../../shared_resources_clean/eva/models/actividades_model', 'Actividades_model', true);

	    $call_function = $self->uri->segment(3);
	    switch ($call_function) {
	    	case "getAllActivities":
				$result 						= $self->Actividades_model->getActividades();
				break;
			case "getClientActivities":
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$result 						= $self->Actividades_model->getActividadesCliente($params);
				break;
			case 'createActivity':
				$params['titulo']				= $self->input->post('titulo');
				$result 						= $self->Actividades_model->createActivity($params);
				break;
			case 'asignActivityToClient':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idActividad']			= $self->input->post('idActividad');
				$params['estado']				= $self->input->post('estado');
				$params['initDate']				= $self->input->post('initDate');
				$params['endDate']				= $self->input->post('endDate');
				$result 						= $self->Actividades_model->asignActivityToCLient($params);
				break;
			case 'updateActividades':
				$params['idActividad']			= $self->input->post('idActividad');
				$params['titulo']				= $self->input->post('titulo');
				$result 						= $self->Actividades_model->updateActividades($params);
				break;
			case 'updateFechasActividades':
				$params['initDate']				= $self->input->post('initDate');
				$params['endDate']				= $self->input->post('endDate');
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idActividad']			= $self->input->post('idActividad');
				$result 						= $self->Actividades_model->updateFechasActividades($params);
				break;
	    }
	    return $result;
	}// end actividades_api()

	private function archivos_api($sitio) {
		$self =& get_instance();
	    $self->load->model('../../../../shared_resources_clean/eva/models/archivos_model', 'Archivos_model', true);

	    $call_function = $self->uri->segment(3);
	    switch ($call_function) {
	    	case 'getFilesClient':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$result 						= $self->Archivos_model->getArchivosCliente($params);
				break;
	    	case 'getUrlFileInCommentary':
				$params['idComentario']			= $self->input->post('idComentario');
				$result 						= $self->Archivos_model->isFileInComentary($params);
				break;
			case 'getUrlFileInActivity':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idActividad']			= $self->input->post('idActividad');
				$result 						= $self->Archivos_model->isFileInActivity($params);
				break;
			case 'uploadFIle': //Asign the URL of the file upload to data base
				$params['url']					= $self->input->post('url');
				$result 						= $self->Archivos_model->uploadFile($params);
				break;
			case 'asignFileToActivity':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idArchivo']			= $self->input->post('idArchivo');
				$params['idActividad']			= $self->input->post('idActividad');
				$result 						= $self->Archivos_model->insertFileByActivity($params);
				break;
			case 'asignFileToCommentary':
				$params['idComentario']			= $self->input->post('idComentario');
				$params['idArchivo']			= $self->input->post('idArchivo');
				$result 						= $self->Archivos_model->insertFileByCommentary($params);
				break;
			case 'asignFileToClient':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idArchivo']			= $self->input->post('idArchivo');
				$result 						= $self->Archivos_model->insertFileByCliente($params);
				break;
	    }
	    return $result;
	}// end archivos_api()

	private function clientes_api($sitio) {
		$self =& get_instance();
	    $self->load->model('../../../../shared_resources_clean/eva/models/clientes_model', 'Clientes_model', true);

	    $call_function = $self->uri->segment(3);
	    switch ($call_function) {
	    	case "getClientes":
				$result 						= $self->Clientes_model->getClientes();
				break;
	    	case 'getSettings':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$result 						= $self->Clientes_model->getSettings($params);
				break;
			case 'createCliente':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idUsuario']			= $self->input->post('idUsuario');
				$params['sucursalBancaria']		= $self->input->post('sucursalBancaria');
				$params['noCuenta']				= $self->input->post('noCuenta');
				$params['frecuenciaDePago']		= $self->input->post('frecuenciaDePago');
				$params['inventario']			= $self->input->post('inventario');
				$params['comision']				= $self->input->post('comision');
				$result 						= $self->Clientes_model->createCliente($params);
				break;
			case 'updateClientInfo':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idUsuario']			= $self->input->post('idUsuario');
				$params['sucursalBancaria']		= $self->input->post('sucursalBancaria');
				$params['noCuenta']				= $self->input->post('noCuenta');
				$params['frecuenciaDePago']		= $self->input->post('frecuenciaDePago');
				$params['inventario']			= $self->input->post('inventario');
				$params['comision']				= $self->input->post('comision');
				$result 						= $self->Clientes_model->updateClient($params);
				break;
			case 'addClientToFavorites':
				$params['idUsuario']			= $self->input->post('idUsuario');
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$result 						= $self->Clientes_model->addClientToFavorites($params);
				break;
	    }
	    return $result;
	}// end clientes_api()

	private function comentarios_api($sitio) {
		$self =& get_instance();
	    $self->load->model('../../../../shared_resources_clean/eva/models/comentarios_model', 'Comentarios_model', true);

	    $call_function = $self->uri->segment(3);
	    switch ($call_function) {
	    	case 'getCommentaries':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['numComentInit']		= $self->input->post('numComentInit');
				$params['numComentEnd']			= $self->input->post('numComentEnd');
				$result 						= $self->Comentarios_model->getComentarios($params);
				break;
	    	case 'createCommentary':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['comentario']			= $self->input->post('comentario');
				$params['idUsuario']			= $self->input->post('idUsuario');
				$result 						= $self->Comentarios_model->createCommentary($params);
				break;
	    }
	    return $result;
	}// end comentarios_api()

	private function contactos_api($sitio) {
		$self =& get_instance();
	    $self->load->model('../../../../shared_resources_clean/eva/models/contactos_model', 'Contactos_model', true);

	    $call_function = $self->uri->segment(3);
	    switch ($call_function) {
	    	case "getContact":
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$result 						= $self->Contactos_model->getContactos($params);
				break;
	    	case "getContactInfo":
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['nombreContacto']		= $self->input->post('nombreContacto');
				$result 						= $self->Contactos_model->getContactInfo($params);
				break;
			case 'createContact':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['nombreContacto']		= $self->input->post('nombreContacto');
				$params['puestoContacto']		= $self->input->post('puestoContacto');
				$result 						= $self->Contactos_model->createContanct($params);
				break;
			case 'insertMailIntoContact':
				$params['idContacto']			= $self->input->post('idContacto');
				$params['correo']				= $self->input->post('correo');
				$result 						= $self->Contactos_model->createContactDataMail($params);
				break;
			case 'insertTelephoneIntoContact':
				$params['idContacto']			= $self->input->post('idContacto');
				$params['telefono']				= $self->input->post('telefono');
				$result 						= $self->Contactos_model->createContactDataTelephone($params);
				break;
			case 'updateContactInfo':
				$params['idContacto']			= $self->input->post('idContacto');
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['nombreContacto']		= $self->input->post('nombreContacto');
				$params['puestoContacto']		= $self->input->post('puestoContacto');
				$result 						= $self->Contactos_model->updateContactInfo($params);
				break;
			case 'updateContactMail':
				$params['idCorreo']				= $self->input->post('idCorreo');
				$params['correo']				= $self->input->post('correo');
				$result 						= $self->Contactos_model->updateContactMail($params);
				break; 
			case 'updateContactTelephone':
				$params['idCorreo']				= $self->input->post('idCorreo');
				$params['correo']				= $self->input->post('correo');
				$result 						= $self->Contactos_model->updateContactTelephone($params);
				break;
	    }
	    return $result;
	}// end contactos_api()

	private function tareas_api($sitio) {
		$self =& get_instance();
	    $self->load->model('../../../../shared_resources_clean/eva/models/tareas_model', 'Tareas_model', true);

	    $call_function = $self->uri->segment(3);
	    switch ($call_function) {
	    	case "getTareas":
				$params['nombreCliente'] 		= $self->input->post('nombreCliente');
				$result 						= $self->Tareas_model->getTareasClientes($params);
				break;
	    	case 'asignTareaToClient':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['tarea']				= $self->input->post('tarea');
				$result 						= $self->Tareas_model->createTareaByCliente($params);
				break;
	    }
	    return $result;
	}// end tareas_api()

	private function usuarios_api($sitio) {
		$self =& get_instance();
	    $self->load->model('../../../../shared_resources_clean/eva/models/usuarios_model', 'Usuarios_model', true);

	    $call_function = $self->uri->segment(3);
	    switch ($call_function) {
	    	case 'getDataUser':
	    		$params['idUsuario']			= $self->input->post('idUsuario');
	    		$result 						= $self->Usuarios_model->getDataUser($params);
	    		break;
	    	case 'createUser':
				$params['nombre']				= $self->input->post('nombre');
				$params['password']				= $self->input->post('password');
				$params['mail']					= $self->input->post('mail');
				$params['telefono']				= $self->input->post('telefono');
				$result 						= $self->Usuarios_model->createUser($params);
				break;
			case 'changeUserPassword':
				$params['idUsuario']			= $self->input->post('idUsuario');
				$params['oldPassword']			= $self->input->post('oldPassword');
				$params['newPassword']			= $self->input->post('newPassword');
				$params['mail']					= $self->input->post('mail');
				$result 						= $self->Usuarios_model->changeUserPassword($params);
				break;
			case 'updateUserInfo':
				$params['nombre']				= $self->input->post('nombre');
				$params['mail']					= $self->input->post('mail');
				$params['telefono']				= $self->input->post('telefono');
				$params['idUsuario']			= $self->input->post('idUsuario');
				$result 						= $self->Usuarios_model->updateUserInfo($params);
				break;
	    }
	    return $result;
	}

	// Solo para referencia, borrar despues
	private function eva_api($sitio){

	    $self =& get_instance();
	    $self->load->model('../../../../shared_resources_clean/eva/models/eva_model', 'Eva_model', true);

	    $call_function = $self->uri->segment(3);
    	switch($call_function){
			case "getClientes":
				$result 						= $self->Eva_model->getClientes();
				break;
			case "getContact":
				$params['nombreContacto']		= $self->input->post('nombreContacto');
				$result 						= $self->Eva_model->getContactos($params);
				break;
			case "getMailContact":
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['nombreContacto']		= $self->input->post('nombreContacto');
				$result 						= $self->Eva_model->getContactoMail($params);
				break;
			case "getTelephoneContact":
				$params['nombreCliente'] 		= $self->input->post('nombreCliente');
				$params['nombreContacto']		= $self->input->post('nombreContacto');
				$result 						= $self->Eva_model->getContactoTelefono($params);
				break;
			case "getTareas":
				$params['nombreCliente'] 		= $self->input->post('nombreCliente');
				$result 						= $self->Eva_model->getTareasClientes($params);
				break;
			case "getAllActivities":
				$result 						= $self->Eva_model->getActividades();
				break;
			case "getClientActivities":
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$result 						= $self->Eva_model->getActividadesCliente($params);
				break;
			case 'getFilesClient':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$result 						= $self->Eva_model->getArchivosCliente($params);
				break;
			case 'getSettings':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$result 						= $self->Eva_model->getSettings($params);
				break;
			case 'getCommentaries':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['numComentInit']		= $self->input->post('numComentInit');
				$params['numComentEnd']			= $self->input->post('numComentEnd');
				$result 						= $self->Eva_model->getComentarios($params);
				break;
			case 'getUrlFileInCommentary':
				$params['idComentario']			= $self->input->post('idComentario');
				$result 						= $self->Eva_model->isFileInComentary($params);
				break;
			case 'getUrlFileInActivity':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idActividad']			= $self->input->post('idActividad');
				$result 						= $self->Eva_model->isFileInActivity($params);
				break;
			case 'createCliente':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idUsuario']			= $self->input->post('idUsuario');
				$params['sucursalBancaria']		= $self->input->post('sucursalBancaria');
				$params['noCuenta']				= $self->input->post('noCuenta');
				$params['fechaIngreso']			= $self->input->post('fechaIngreso');
				$params['frecuenciaDePago']		= $self->input->post('frecuenciaDePago');
				$params['inventario']			= $self->input->post('inventario');
				$params['comision']				= $self->input->post('comision');
				$result 						= $self->Eva_model->createCliente($params);
				break;
			case 'createUser':
				$params['nombre']				= $self->input->post('nombre');
				$params['password']				= $self->input->post('password');
				$params['mail']					= $self->input->post('mail');
				$params['telefono']				= $self->input->post('telefono');
				$result 						= $self->Eva_model->createUser($params);
				break;
			case 'createActivity':
				$params['titulo']				= $self->input->post('titulo');
				$result 						= $self->Eva_model->createActivity($params);
				break;
			case 'asignActivityToClient':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idActividad']			= $self->input->post('idActividad');
				$params['estado']				= $self->input->post('estado');
				$result 						= $self->Eva_model->asignActivityToCLient($params);
				break;
			case 'createContact':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['nombreContacto']		= $self->input->post('nombreContacto');
				$params['puestoContacto']		= $self->input->post('puestoContacto');
				$result 						= $self->Eva_model->createContanct($params);
				break;
			case 'asignContactToClient':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idContacto']			= $self->input->post('idContacto');
				$result 						= $self->Eva_model->asignContactToClient($params);
				break;
			case 'insertMailIntoContact':
				$params['idContacto']			= $self->input->post('idContacto');
				$params['correo']				= $self->input->post('correo');
				$result 						= $self->Eva_model->createContactDataMail($params);
				break;
			case 'insertTelephoneIntoContact':
				$params['idContacto']			= $self->input->post('idContacto');
				$params['telefono']				= $self->input->post('telefono');
				$result 						= $self->Eva_model->createContactDataTelephone($params);
				break;
			case 'asignTareaToClient':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['fechaCreacion']		= $self->input->post('fechaCreacion');
				$params['tarea']				= $self->input->post('tarea');
				$result 						= $self->Eva_model->createTareaByCliente($params);
				break;
			case 'uploadFIle': //Asign the URL of the file upload to data base
				$params['url']					= $self->input->post('url');
				$result 						= $self->Eva_model->uploadFile($params);
				break;
			case 'asignFileToActivity':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idArchivo']			= $self->input->post('idArchivo');
				$params['idActividad']			= $self->input->post('idActividad');
				$result 						= $self->Eva_model->insertFileByActivity($params);
				break;
			case 'asignFileToCommentary':
				$params['idComentario']			= $self->input->post('idComentario');
				$params['idArchivo']			= $self->input->post('idArchivo');
				$result 						= $self->Eva_model->insertFileByCommentary($params);
				break;
			case 'createCommentary':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['comentario']			= $self->input->post('comentario');
				$params['fechaEnvio']			= $self->input->post('fechaEnvio');
				$result 						= $self->Eva_model->createCommentary($params);
				break;
			case 'updateClientInfo':
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['idUsuario']			= $self->input->post('idUsuario');
				$params['sucursalBancaria']		= $self->input->post('sucursalBancaria');
				$params['noCuenta']				= $self->input->post('noCuenta');
				$params['frecuenciaDePago']		= $self->input->post('frecuenciaDePago');
				$params['inventario']			= $self->input->post('inventario');
				$params['comision']				= $self->input->post('comision');
				$result 						= $self->Eva_model->updateClient($params);
				break;
			case 'updateContactInfo':
				$params['idContacto']			= $self->input->post('idContacto');
				$params['nombreCliente']		= $self->input->post('nombreCliente');
				$params['nombreContacto']		= $self->input->post('nombreContacto');
				$params['puestoContacto']		= $self->input->post('puestoContacto');
				$result 						= $self->Eva_model->updateContactInfo($params);
				break;
			case 'updateContactMail':
				$params['idCorreo']				= $self->input->post('idCorreo');
				$params['correo']				= $self->input->post('correo');
				$params['idContacto']			= $self->input->post('idContacto');
				$result 						= $self->Eva_model->updateContactMail($params);
				break;
			case 'updateContactTelephone':
				$params['idCorreo']				= $self->input->post('idCorreo');
				$params['correo']				= $self->input->post('correo');
				$params['idContacto']			= $self->input->post('idContacto');
				$result 						= $self->Eva_model->updateContactTelephone($params);
				break;
			case 'changeUserPassword':
				$params['idUsuario']			= $self->input->post('idUsuario');
				$params['oldPassword']			= $self->input->post('oldPassword');
				$params['newPassword']			= $self->input->post('newPassword');
				$params['mail']					= $self->input->post('mail');
				$result 						= $self->Eva_model->changeUserPassword($params);
				break;
			case 'updateUserInfo':
				$params['nombre']				= $self->input->post('nombre');
				$params['mail']					= $self->input->post('mail');
				$params['telefono']				= $self->input->post('telefono');
				$params['idUsuario']			= $self->input->post('idUsuario');
				$result 						= $self->Eva_model->updateUserInfo($params);
				break;
			case 'updateTarea':
				$params['idTarea']				= $self->input->post('idTarea');
				$params['tarea']				= $self->input->post('tarea');
				$result 						= $self->Eva_model->updateTarea($params);
				break;
			case 'updateActividades':
				$params['idActividad']			= $self->input->post('idActividad');
				$params['titulo']				= $self->input->post('titulo');
				$result 						= $self->Eva_model->updateActividades($params);
				break;
		}

		return $result;
	}
}// end class
	/*
	 * Por que en nuestro intento de enmarcar las cosas y glorificar nuestros egos decidimos encerrar los comentarios con dos lineas si 
	 * es que estos ocupan solo un renglon, o con /* y su otro amigo para cuando las cosas ocupan mas espacio??
	 * Acaso unos son mejores que otros, no se supone que son iguales?, entonces por que no quitarnos de prejuicios y dejar de haer 
	 * distinciones entre los comentarios como las hacemos entre las personas, no tenemos que vernos forzados a etiquetar todo a tal punto
	 * de que hasta nuestro codigo tienen que ser objeto de ello.
	 * ¡¡No a la discriminación en el codigo!!
	 */
/* End of file Eva_api.php */
?>