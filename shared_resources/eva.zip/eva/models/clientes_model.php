<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Clientes_model extends CI_Model {

	// The default constructor
	function __construct() {
		parent::__construct();
		date_default_timezone_set('America/Mexico_City');
	}

	public function getClientes() {
		$result = array();

		$this->db->select('nombreCliente');
		$this->db->from('Clientes');

		$resultadoClientes = $this->db->get();

		return $result = $resultadoClientes->result();

	}// End getClientes();

	public function getSettings($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente) > 0) {
			$this->db->select('nombreCliente, sucursalBancaria, noCuenta, fechaIngreso, frecuenciaDePago, inventario, comision');
			$this->db->from('Clientes');
			$this->db->where('nombreCliente',$nombreCliente);

			$resultadoSettings = $this->db->get();
			if ($resultadoSettings->num_rows() > 0) {
				$result = $resultadoSettings->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end getSettings()

	public function createCliente($params){
		extract($params);

		//Primero checamos si la tienda que daran de alta es una tienda valida (Que no este dada previamente de alta en la base)
		$existeTienda = $this->existClient($params);

		// Comprobamos si todo lo que nos pasan esta en un formato correcto :)
		if ($existeTienda) {
			if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($idUsuario) AND $idUsuario > 0) 
				AND (isset($sucursalBancaria) AND strlen($sucursalBancaria) > 0 ) AND (isset($noCuenta) AND $noCuenta > 0) 
				AND (isset($frecuenciaDePago) AND strlen($frecuenciaDePago) > 0) AND (isset($inventario) AND $inventario >= 0 AND $inventario < 2) 
				AND (isset($comision) AND $comision > 0)) {
				$data_cliente = array(
					'nombreCliente'		=> $nombreCliente,
					'idUsuario'			=> $idUsuario,
					'sucursalBancaria'	=> $sucursalBancaria,
					'noCuenta'			=> $noCuenta,
					'fechaIngreso'		=> date('Y-m-d H:i:s'),
					'frecuenciaDePago'	=> $frecuenciaDePago,
					'inventario'		=> $inventario,
					'comision'			=> $comision
				);
				$this->db->insert('Clientes',$data_cliente);
				$resultInsert = $this->db->affected_rows();
				if ($resultInsert > 0) {
					return true;
				}
				return false;
			}
		}else{
			return false;
		}
	}// end createCliente

	private function existClient($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente)) {
			$this->db->select('nombreCliente');
			$this->db->from('Clientes');
			$this->db->where('nombreCliente',$nombreCliente);

			$aux = $this->db->get();
			if ($aux->num_rows() > 0) {
				return false;
			}
		}
		return true;
	}// end existClient()

	public function updateClient($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($idUsuario) AND $idUsuario > 0) AND (isset($sucursalBancaria) AND strlen($sucursalBancaria) > 0) AND (isset($noCuenta) AND $noCuenta > 0) AND (isset($frecuenciaDePago) AND strlen($frecuenciaDePago) > 0) AND (isset($inventario) AND $inventario >= 0 AND $inventario < 2) AND (isset($comision) AND $comision > 0)) {
			$data_update = array(
				'nombreCliente'		=> $nombreCliente,
				'sucursalBancaria'	=> $sucursalBancaria,
				'noCuenta'			=> $noCuenta,
				'frecuenciaDePago'	=> $frecuenciaDePago,
				'inventario'		=> $inventario,
				'comision'			=> $comision
			);
			$this->db->where('idUsuario',$idUsuario);
			$this->db->where('nombreCliente',$nombreCliente);
			$this->db->update('Clientes', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
	}// end updateClient

	public function addClientToFavorites($params) {
		extract($params);

		if (isset($idUsuario) AND $idUsuario > 0 AND (isset($nombreCliente) AND strlen($nombreCliente) > 0)) {
			$data_insert = array(
				'idUsuario'			=> $idUsuario,
				'nombreCliente'		=> $nombreCliente
			);

			$this->db->insert('Favoritos', $data_insert);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}// end if
	}// end addClientToFavorites()

}
	/*
	 * Que sucede en este momento.
	 * Como saberlo a ciencia cierta si lo unico que conicemos es un estado de incertidumbre perecedera que nos hace y nos 
	 * lleva a actuar como animales ante estados donde la conciencia y el espitutu humano deverian conmover situaciones tales
	 * como la masecre de Ayotzinapa cometida por la barbarie del estado represor e inpio, la ocupación de CU por elementos del 
	 * cuerpo de granaderos, la intimidación a periodistas...
	 * O sin irnos tan lejos a situaciones que de alguna manera a algunas personas pudiese parecer agena (ya que no tienen hijos 
	 * que estudian, y a los que en algun momento por el simple hecho de pensar podrian matar), pensemos en una situación cotidiana 
	 * simplemente vas caminando por la calle sin meterte con nadie y alguien te asalta, viola tu libertad y tedespoja de tus 
	 * pertenencias, o vas en el transporte publico y te matan por no querer dar tus pertenecias, o afuera del Kinder de tus hijos,
	 * o de la primaria donde estudian hay personas que venden droga a tus hijos. Pero despues de todo no pasa nada, es culpa de la 
	 * gente que la maten, si te estan asaltando por que tienes que resistirte, te toco y ya, a ahorrar de nuevo y comprarte tus cosas
	 * es culpade los padres el que vendan drogas en las escuelas, o de las autoridades de esta, pero nunca de la sociedad, depues de 
	 * todo no se puede hacer nada, ¿no?
	 * La respuesta es simple, si no haces  nada entonces no te quejes, y vive conformista como siempre :P
	 */
?>