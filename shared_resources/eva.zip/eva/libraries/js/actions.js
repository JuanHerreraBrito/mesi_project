// equals $(document).ready(function(){});
$(function() {
	$.ajax({
		url: 'sell3.kichink.nb9.mx/api/clients/getClientes',
		type: 'post',
		//data: {},
		success: function(data, status) {
			if (data == 'ok') {
				console.log('De alguna manera me trajo los datos...');
			}
		},
		error: function(xhr, desc, err) {
			console.log(xhr);
        	console.log("Details: " + desc + "\nError:" + err);
		}
	});// end ajax call
});
	/*
	 * One more commentary, one more commentary for this files.
	 * Some times I dont know why I do this, sometimes I know...
	 * "Wetheber" they be... I'm Happy :)
	 */

// end document