<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tareas_model extends CI_Model {

	// The default constructor
	function __construct() {
		parent::__construct();
		date_default_timezone_set('America/Mexico_City');
	}

	public function getTareasClientes($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente) > 0) {
			$this->db->select('idTarea, fechaCreacion, tarea');
			$this->db->from('Tareas');
			$this->db->where('nombreCliente',$nombreCliente);

			$resultadoTareasClientes = $this->db->get();
			if ($resultadoTareasClientes->num_rows() > 0) {
				$result = $resultadoTareasClientes->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end getTareasClientes()

	public function createTareaByCliente($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($tarea) AND strlen($tarea) > 0)) {
			$data_tareas = array(
				'nombreCliente'		=> $nombreCliente,
				'fechaCreacion'		=> date('Y-m-d H:i:s'),
				'tarea'				=> $tarea
			);
			$this->db->insert('Tareas', $data_tareas);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end createTareaByCliente()
}
	/*
	 * La vida de los santos como la de los no santos es algunas vees tan compleja y otras tan simple.
	 * No lo se, simplemente es una cosa de suerte aunada con un poco de destino, destino el cual viene
	 * acompañado con todo...
	 * (no estoy inspirado, so no puedo escrivir como de costumbre)
	 */

?>