<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Actividades_model extends CI_Model {

	// The default constructor
	function __construct() {
		parent::__construct();
		date_default_timezone_set('America/Mexico_City');
	}

	public function getActividades() {

		$this->db->select('titulo, idActividad');
		$this->db->from('Actividades');

		$result = array();
		$resultadoActividades = $this->db->get();
		if ($resultadoActividades->num_rows() > 0) {
			$result = $resultadoActividades->result();
		}
		return $result;
	}// end getActividades()

	public function getActividadesCliente($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente) > 0) {
			$this->db->select('C.nombreCliente, C.estado, C.initDate, C.endDate, A.titulo');
			$this->db->from('Clientes_has_Actividades AS C');
			$this->db->join('Actividades AS A', 'A.idActividad = C.idActividad', 'inner');
			$this->db->where('C.nombreCliente',$nombreCliente);
			/*
			 * Esta consulta trae el siguente Query
			 * Select C.nombreCliente, C.idActividad, C.estado, A.titulo, A.idActividad
			 * 	FROM Clientes_has_Actividades AS C
    		 * 	INNER JOIN Actividades AS A
			 * 		ON A.idActividad = C.idActividad
			 * 	WHERE C.nombreCliente = 'DualCorp'
    		 * 	AND C.estado = TRUE;
			 */
			$resultadoActividadesCliente = $this->db->get();
			if ($resultadoActividadesCliente->num_rows() > 0) {
				$result = $resultadoActividadesCliente->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end getActividadesCliente()

	public function createActivity($params) {
		extract($params);

		// checamos si la actividad no existe :)
		$existActivity = true;
		if (isset($titulo) AND strlen($titulo)) {
			$this->db->select('idActividad');
			$this->db->from('Actividades');
			$this->db->like('titulo',$titulo);

			$resActivityExist = $this->db->get();
			if ($resActivityExist->num_rows() > 0) {
				$existActivity = false;
			}
		}
		
		if ($existActivity) {
			if (isset($titulo) AND strlen($titulo)) {
				$data_activity = array(
					'titulo'	=> $titulo
				);
				$this->db->insert('Actividades', $data_activity);
				$resultInsert = $this->db->affected_rows();
				if ($resultInsert > 0) {
					return true;
				}
				return false;
 			}
		}else{
			return false;
		}// end else
	}// end createActivity()

	public function asignActivityToCLient($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($idActividad) AND $idActividad > 0) AND (isset($estado) AND ($estado == 1 OR $estado == 0))) {
			if (isset($initDate) AND strtotime($initDate) AND (isset($endDate) AND strtotime($endDate))) {
				$data_C_h_A = array(
					'nombreCliente'		=> $nombreCliente,
					'idActividad'		=> $idActividad,
					'estado'			=> $estado,
					'initDate'			=> $initDate,
					'endDate'			=> $endDate
				);
				$this->db->insert('Clientes_has_Actividades', $data_C_h_A);
				$resultInsert = $this->db->affected_rows();
			}else{
				$data_C_h_A = array(
					'nombreCliente'		=> $nombreCliente,
					'idActividad'		=> $idActividad,
					'estado'			=> $estado
				);
				$this->db->insert('Clientes_has_Actividades', $data_C_h_A);
				$resultInsert = $this->db->affected_rows();
			}
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
	}// end asignActivityToCLient()

	public function updateActividades($params) {
		extract($params);

		if ((isset($idActividad) AND $idActividad > 0) AND (isset($titulo) AND strlen($titulo) > 0)) {
			$data_update = array(
				'titulo'	=> $titulo
			);
			$this->db->where('idActividad', $idActividad);
			$this->db->update('Actividades', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
	}// end updateActividades()

	public function updateFechasActividades($params) {
		extract($params);

		if (isset($initDate) AND strtotime($initDate) AND (isset($endDate) AND strtotime($endDate)) AND (isset($nombreCliente)
			AND strlen($nombreCliente) > 0) AND (isset($idActividad) AND $idActividad > 0)) {
			$data_update = array(
				'initDate'		=> $initDate,
				'endDate'		=> $endDate
			);
			$this->db->where('nombreCliente', $nombreCliente);
			$this->db->where('idActividad', $idActividad);
			$this->db->update('Clientes_has_Actividades', $data_update);
			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
	}// end updateFechasActividades()

} // end class
	/*	
	 * Este es el final de un archivo. Tal vez podria compararse con el final de una vida para un humano, pero si esto es similar de alguna forma entonces un archivo es mejor que un humano,
	 * Ya que este tiene la posibilidad de resicitar pues cada vez que es ejecutado es como si volviera a vivir una vez mas, y es en este punto cuando yo me pregunto si esto tambien se puede aplicar 
	 * para un programador, ya que de cierta manera nosotros hicimos este codigo, entonces de alguna manera al ejecutarse este archivo estara haciendo una especie de homenaje o remembranza de su creador.
	 * Si esto fuese cierto entonces nosotros podriamos vivir eternamente atravez del recuerdo de nuestros programas.... 
	 * Luis Alberto Cruz, un computologo un poco loco :) 
	 */
?>