<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Eva_model extends CI_Model {

	// The default constructor
	function __construct() {
		parent::__construct();
		date_default_timezone_set('America/Mexico_City');
	}

	//Start Getters 

	public function getClientes() {
		$result = array();

		$this->db->select('nombreCliente');
		$this->db->from('Clientes');

		$resultadoClientes = $this->db->get();

		return $result = $resultadoClientes->result();

	}// End getClientes();

	public function getContactos($params){
		extract($params);

		$result = array();
		if (isset($nombreContacto) AND strlen($nombreContacto)) {
			$this->db->select('idContacto, nombreContacto, puestoContacto');
			$this->db->from('Contactos');
			$this->db->where('nombreContacto',$nombreContacto);

			$resultadoClientes = $this->db->get();
			if ($resultadoClientes->num_rows() > 0) {
				$result = $resultadoClientes->result();
			}
		}
		return $result;
	}// end getContactos()

	public function getDataUser($params) {
		extract($params);

		$result = array();
		if (isset($idUsuario) AND $idUsuario > 0) {
			$this->db->select('nombre, mail, telefono');
			$this->db->from('Usuarios');
			$this->db->where('idUsuario',$idUsuario);

			$resultUsers = $this->db->get();
			if ($resultUsers->num_rows() > 0) {
				$result = $resultUsers->result();
			}
		}
		return $result;
	}// end getDataUser()

	public function getContactoMail($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($nombreContacto) AND strlen($nombreContacto) > 0)) {
			$this->db->select('C.nombreCliente, M.correo, CT.nombreContacto, CT.puestoContacto');
			$this->db->from('Clientes AS C');
			$this->db->join('Directorio AS D', 'C.nombreCliente = D.nombreCliente', 'inner');
			$this->db->join('Contactos AS CT', 'CT.idContacto = D.idContacto', 'inner');
			$this->db->join('Correos AS M', 'CT.idContacto = M.Contactos_idContacto', 'inner');
			$this->db->where('C.nombreCliente',$nombreCliente);
			$this->db->where('CT.nombreContacto',$nombreContacto);
			/*
			 * Esta consulta trae el siguiente Query
			 * SELECT C.nombreCliente, M.correo, CT.nombreContacto, CT.puestoContacto -- M.correo
			 * 	FROM Clientes AS C
    		 * 	INNER JOIN Directorio AS D 
			 * 		ON C.nombreCliente = D.nombreCliente
			 * 	INNER JOIN Contactos AS CT
			 * 		ON CT.idContacto = D.idContacto
			 * 	INNER JOIN Correos AS M
			 * 		ON CT.idContacto = M.Contactos_idContacto
			 * 	WHERE C.nombreCliente = $nombreCliente
    		 * 	AND CT.nombreContacto = $nombreContacto;
			 */

			$correosElectronicos = $this->db->get();
			if ($correosElectronicos->num_rows() > 0) {
				$result = $correosElectronicos->result();
			}
			return $result;
		}else{ //Si la tienda no existe regresamos false
			return false;
		}
	}// end getContactoMail()

	public function getContactoTelefono($params){
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($nombreContacto) AND strlen($nombreContacto) > 0)) {

			$this->db->select('C.nombreCliente, T.telefono, CT.nombreContacto, CT.puestoContacto');
			$this->db->from('Clientes AS C');
			$this->db->join('Directorio AS D', 'C.nombreCliente = D.nombreCliente', 'inner');
			$this->db->join('Contactos AS CT', 'CT.idContacto = D.idContacto', 'inner');
			$this->db->join('Telefonos AS T', 'CT.idContacto = T.Contactos_idContacto', 'inner');
			$this->db->where('C.nombreCliente',$nombreCliente);
			$this->db->where('CT.nombreContacto',$nombreContacto);
			/*
			 * Esta consulta trae el siguiente Query
			 * SELECT C.nombreCliente, T.telefono, CT.nombreContacto, CT.puestoContacto -- M.correo
			 * 	FROM Clientes AS C
    		 * 	INNER JOIN Directorio AS D 
			 * 		ON C.nombreCliente = D.nombreCliente
			 * 	INNER JOIN Contactos AS CT
			 * 		ON CT.idContacto = D.idContacto
			 * 	INNER JOIN Telefonos AS T
			 * 		ON CT.idContacto = T.Contactos_idContacto
			 * 	WHERE C.nombreCliente = $nombreCliente
    		 * 	AND CT.nombreContacto = $nombreContacto;
			 */

			$telefonosContacto = $this->db->get();
			if ($telefonosContacto->num_rows() > 0) {
				$result = $telefonosContacto->result();
			}
			return $result;
		}else{ //Si la tienda no existe regresamos false
			return false;
		}
	}// end getContactoTelefono()

	public function getTareasClientes($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente) > 0) {
			$this->db->select('idTarea, fechaCreacion, tarea');
			$this->db->from('Tareas');
			$this->db->where('nombreCliente',$nombreCliente);

			$resultadoTareasClientes = $this->db->get();
			if ($resultadoTareasClientes->num_rows() > 0) {
				$result = $resultadoTareasClientes->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end getTareasClientes()

	public function getActividades() {

		$this->db->select('titulo');
		$this->db->from('Actividades');

		$resultadoActividades = $this->db->get();
		return $resultadoActividades->result();
	}// end getActividades()

	public function getActividadesCliente($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente) > 0) {
			$this->db->select('C.nombreCliente, C.estado, A.titulo');
			$this->db->from('Clientes_has_Actividades AS C');
			$this->db->join('Actividades AS A', 'A.idActividad = C.idActividad', 'inner');
			$this->db->where('C.nombreCliente',$nombreCliente);
			/*
			 * Esta consulta trae el siguente Query
			 * Select C.nombreCliente, C.idActividad, C.estado, A.titulo, A.idActividad
			 * 	FROM Clientes_has_Actividades AS C
    		 * 	INNER JOIN Actividades AS A
			 * 		ON A.idActividad = C.idActividad
			 * 	WHERE C.nombreCliente = 'DualCorp'
    		 * 	AND C.estado = TRUE;
			 */
			$resultadoActividadesCliente = $this->db->get();
			if ($resultadoActividadesCliente->num_rows() > 0) {
				$result = $resultadoActividadesCliente->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end getActividadesCliente()

	public function getArchivosCliente($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente)) {
			$this->db->select('A.url, A.idArchivo');
			$this->db->from('Clientes_has_Archivos AS H');
			$this->db->join('Archivos', 'H.idArchivo = A.idArchivo', 'inner');
			$this->db->where('nombreCliente',$nombreCliente);

			$resultadoArchivosClientes = $this->db->get();
			if ($resultadoArchivosClientes->num_rows() > 0) {
				$result = $resultadoArchivosClientes->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end getArchivos()

	public function getSettings($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente) > 0) {
			$this->db->select('nombreCliente, sucursalBancaria, noCuenta, fechaIngreso, frecuenciaDePago, inventario, comision');
			$this->db->from('Clientes');
			$this->db->where('nombreCliente',$nombreCliente);

			$resultadoSettings = $this->db->get();
			if ($resultadoSettings->num_rows() > 0) {
				$result = $resultadoSettings->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end getSettings()


	public function getComentarios($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente)) {
			if (isset($numComentInit) AND $numComentInit >= 0 AND (isset($numComentEnd) AND $numComentEnd > $numComentInit)) {
				$this->db->select('C.comentario, C.fechaEnvio');
				$this->db->from('Clientes_has_Comentarios AS H');
				$this->db->join('Comentarios AS C', 'H.idComentario = C.idComentario', 'inner');
				$this->db->where('H.nombreCliente',$nombreCliente);
				$this->db->limit($numComentEnd, $numComentInit);

				$commentaries = $this->db->get();
				if ($commentaries->num_rows() > 0) {
					$result = $commentaries->result();
				}
			}else{
				$this->db->select('comentario, fechaEnvio');
				$this->db->from('Clientes_has_Comentarios AS H');
				$this->db->join('Comentarios AS C', 'H.idComentario = C.idComentario', 'inner');
				$this->db->where('H.nombreCliente',$nombreCliente);
				$this->db->limit(3);

				$commentaries = $this->db->get();
				if ($commentaries->num_rows() > 0) {
					$result = $commentaries->result();
				}
			}
			return $result;
		}else{
			return false;
		}
	}// end getComentaios()


	//Get the url from the Commentary if it take a File.
	public function isFileInComentary($params) {
		extract($params);

		$result = array();
		if (isset($idComentario) AND $idComentario > 0) {
			$this->db->select('A.url');
			$this->db->from('Comentarios_has_Archivos AS H');
			$this->db->join('Archivos AS A', 'H.idArchivo = A.idArchivo', 'inner');
			$this->db->where('H.idComentario',$idComentario);

			$resultadoArchivosComentarios = $this->db->get();
			if ($resultadoArchivosComentarios->num_rows() > 0) {
				$result = $resultadoArchivosComentarios->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end isFileInComentary()

	public function isFileInActivity($params){
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente) AND (isset($idActividad) AND $idActividad > 0)) {
			$this->db->select('A.url');
			$this->db->from('Clientes_has_Actividades_has_Archivos AS H');
			$this->db->join('Archivos AS A', 'H.idArchivo = A.idArchivo', 'inner');
			$this->db->where('H.nombreCliente',$nombreCliente);
			$this->db->where('H.idActividad',$idActividad);

			$resultadoFileInActivity = $this->db->get();
			if ($resultadoFileInActivity->num_rows() > 0) {
				$result = $resultadoFileInActivity->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end isFileInActivity()

	// end Getters


	// Start Setters
		// Setter by create


	public function createCliente($params){
		extract($params);

		//Primero checamos si la tienda que daran de alta es una tienda valida (Que no este dada previamente de alta en la base)
		$existeTienda = $this->existClient($params);

		// Comprobamos si todo lo que nos pasan esta en un formato correcto :)
		if ($existeTienda) {
			if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($idUsuario) AND $idUsuario > 0) AND (isset($sucursalBancaria) AND strlen($sucursalBancaria) > 0 ) AND (isset($noCuenta) AND $noCuenta > 0) AND (isset($fechaIngreso) AND strtotime($fechaIngreso)) AND (isset($frecuenciaDePago) AND strlen($frecuenciaDePago) > 0) AND (isset($inventario) AND $inventario >= 0 AND $inventario < 2) AND (isset($comision) AND $comision > 0)) {
				$data_cliente = array(
					'nombreCliente'		=> $nombreCliente,
					'idUsuario'			=> $idUsuario,
					'sucursalBancaria'	=> $sucursalBancaria,
					'noCuenta'			=> $noCuenta,
					'fechaIngreso'		=> $fechaIngreso,
					'frecuenciaDePago'	=> $frecuenciaDePago,
					'inventario'		=> $inventario,
					'comision'			=> $comision
				);
				$this->db->insert('Clientes',$data_cliente);
				$resultInsert = $this->db->affected_rows();
				if ($resultInsert > 0) {
					return true;
				}
				return false;
			}
		}else{
			return false;
		}
	}// end createCliente

	private function existClient($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente)) {
			$this->db->select('nombreCliente');
			$this->db->from('Clientes');
			$this->db->where('nombreCliente',$nombreCliente);

			$aux = $this->db->get();
			if ($aux->num_rows() > 0) {
				return false;
			}
		}
		return true;
	}

	public function createUser($params) {
		extract($params);

		// Revisamos que el usuario no exista de acuerdo a su correo electronico
		if ($this->existUser($params)) {
			if ((isset($nombre) AND strlen($nombre) > 0) AND (isset($password) AND strlen($password) > 0) AND (isset($mail) AND strlen($mail) > 0) AND (isset($telefono) AND strlen($telefono) > 0)) {
				$data_user = array(
					'nombre'		=> $nombre,
					'password'		=> $password,
					'mail'			=> $mail,
					'telefono'		=> $telefono
				);
				$this->db->insert('Usuarios', $data_user);
				$resultInsert = $this->db->affected_rows();
				if ($resultInsert > 0) {
					return true;
				}
				return false;
			}// end if
		}// end if
		return false;
	}// end createUser()

	private function existUser($params) {
		extract($params);

		$result = true;
		if (isset($mail) AND strlen($mail) > 0) {
			$this->db->select('idUsuario');
			$this->db->from('Usuarios');
			$this->db->where('mail',$mail);

			$aux = $this->db->get();
			if ($aux->num_rows() > 0) {
				$result = false;
			}
		}
		return $result;
	}// end existUser()

	public function createActivity($params) {
		extract($params);

		// checamos si la actividad no existe :)
		$existActivity = true;
		if (isset($titulo) AND strlen($titulo)) {
			$this->db->select('idActividad');
			$this->db->from('Actividades');
			$this->db->like('titulo',$titulo);

			$resActivityExist = $this->db->get();
			if ($resActivityExist->num_rows() > 0) {
				$existActivity = false;
			}
		}
		
		if ($existActivity) {
			if (isset($titulo) AND strlen($titulo)) {
				$data_activity = array(
					'titulo'	=> $titulo
				);
				$this->db->insert('Actividades', $data_activity);
				$resultInsert = $this->db->affected_rows();
				if ($resultInsert > 0) {
					return true;
				}
				return false;
 			}
		}
		return false;
	}// end createActivity()

	public function asignActivityToCLient($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($idActividad) AND $idActividad > 0) AND (isset($estado) AND ($estado == 1 OR $estado == 0))) {
			$data_C_h_A = array(
				'nombreCliente'		=> $nombreCliente,
				'idActividad'		=> $idActividad,
				'estado'			=> $estado
			);
			$this->db->insert('Clientes_has_Actividades', $data_C_h_A);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end asignActivityToCLient()

	public function createContanct($params) {
		extract($params);

		// Revisamos si el contacto no exite
		$existContact = true;
		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($nombreContacto) AND strlen($nombreContacto) > 0)) {
			$this->db->select('idContacto');
			$this->db->from('Contactos');
			$this->db->where('nombreCliente',$nombreCliente);
			$this->db->where('nombreContacto',$nombreContacto);

			$resContactExist = $this->db->get();
			if ($resContactExist->num_rows() > 0) {
				$existContact = false;
			}
		}

		if ($existContact) {
			if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($nombreContacto) AND strlen($nombreContacto) > 0) AND (isset($puestoContacto) AND strlen($puestoContacto) > 0)) {
				$data_contact = array(
					'nombreCliente'		=> $nombreCliente,
					'nombreContacto'	=> $nombreContacto,
					'puestoContacto'	=> $puestoContacto
				);
				$this->db->insert('Contactos',$data_contact);
				$resultInsert = $this->db->affected_rows();
				if ($resultInsert > 0) {
					return true;
				}
				return false;
			}
		}
		return false;
	}// end createContanct()

	public function asignContactToClient($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($idContacto) AND $idContacto > 0)) {
			$data_insert = array(
				'nombreCliente'		=> $nombreCliente,
				'idContacto'		=> $idContacto
			);
			$this->db->insert('Directorio', $data_insert);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
		return false;
	}

	public function createContactDataMail($params) {
		extract($params);

		if (isset($correo) AND strlen($correo) > 0 AND (isset($idContacto) AND $idContacto > 0)) {
			$data_contact = array(
				'idContacto'	=> $idContacto,
				'correo'		=> $correo
			);
			$this->db->insert('Correos', $data_contact);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end createContactDataMail()

	public function createContactDataTelephone($params) {
		extract($params);

		if (isset($telefono) AND strlen($telefono) > 0 AND (isset($idContacto) AND $idContacto > 0)) {
			$data_contact = array(
				'idContacto'	=> $idContacto,
				'telefono'		=> $telefono
			);
			$this->db->insert('Telefonos', $data_contact);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end createContactDataTelephone()

	public function createTareaByCliente($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($fechaCreacion) AND strtotime($fechaCreacion)) AND (isset($tarea) AND strlen($tarea) > 0)) {
			$data_tareas = array(
				'nombreCliente'		=> $nombreCliente,
				'fechaCreacion'		=> $fechaCreacion,
				'tarea'				=> $tarea
			);
			$this->db->insert('Tareas', $data_tareas);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end createTareaByCliente()

	public function uploadFile($params) {
		extract($params);

		if (isset($url) AND strlen($url) > 0) {
			$data_upload = array(
				'url'	=> $url
			);
			$this->db->insert('Archivos', $data_upload);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end uploadFile()

	public function insertFileByCliente($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente) AND (isset($idArchivo) AND $idArchivo > 0)) {
			$data_C_h_A = array(
				'nombreCliente'		=> $nombreCliente,
				'idArchivo'			=> $idArchivo
			);
			$this->db->insert('Clientes_has_Archivos', $data_C_h_A);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return true;
		}
		return true;
	}// end insertFileByCliente

	public function insertFileByActivity($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente) AND (isset($idArchivo) AND $idArchivo > 0) AND (isset($idActividad) AND $idActividad > 0)) {
			$data_C_h_A = array(
				'nombreCliente'		=> $nombreCliente,
				'idActividad'		=> $idActividad,
				'idArchivo'			=> $idArchivo
			);
			$this->db->insert('Clientes_has_Actividades_has_Archivos', $data_C_h_A);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return true;
		}
		return true;
	}// end insertFileByCliente

	public function insertFileByCommentary($params) {
		extract($params);

		if (isset($idComentario) AND $idComentario > 0 AND (isset($idArchivo) AND $idArchivo > 0)) {
			$data_C_h_A = array(
				'idComentario'		=> $idComentario,
				'idArchivo'			=> $idArchivo
			);
			$this->db->insert('Comentarios_has_Archivos', $data_C_h_A);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return true;
		}
		return true;
	}// end insertFileByCliente

	public function createCommentary($params) {
		extract($params);

		if (isset($comentario) AND strlen($comentario) > 0 AND (isset($fechaEnvio) AND strtotime($fechaEnvio)) AND (isset($nombreCliente) AND strlen($nombreCliente) > 0)) {
			$data_commentary = array(
				'comentario'	=> $comentario,
				'fechaEnvio'	=> $fechaEnvio
			);
			$this->db->insert('Comentarios', $data_commentary);
			$insertComment = false;
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				$insertComment = true;
			}
			$insertComment = true;
			if ($insertComment) {
				$idCommentary = 0;
				$this->db->select('idComentario');
				$this->db->from('Comentarios');
				$this->db->order_by('idComentario', 'DESC');
				$this->db->limit(1);

				$aux = $this->db->get();
				$aux_ = $aux->result();
				$idCommentary = $aux_[0]->idComentario;
				if (isset($idCommentary) AND $idCommentary > 0) {
					$data_C_h_C = array(
						'nombreCliente'		=> $nombreCliente,
						'idComentario'		=> $idCommentary
					);
					$this->db->insert('Clientes_has_Comentarios', $data_C_h_C);
					$resultInsert = $this->db->affected_rows();
					if ($resultInsert > 0) {
						return true;
					}
					return false;
				}
				return false;
			}
			return false;
		}
		return false;
	}// end createCommentary();
		// end Setters by create



		// Setters by update
	public function updateClient($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($idUsuario) AND $idUsuario > 0) AND (isset($sucursalBancaria) AND strlen($sucursalBancaria) > 0) AND (isset($noCuenta) AND $noCuenta > 0) AND (isset($frecuenciaDePago) AND strlen($frecuenciaDePago) > 0) AND (isset($inventario) AND $inventario >= 0 AND $inventario < 2) AND (isset($comision) AND $comision > 0)) {
			$data_update = array(
				'nombreCliente'		=> $nombreCliente,
				'sucursalBancaria'	=> $sucursalBancaria,
				'noCuenta'			=> $noCuenta,
				'frecuenciaDePago'	=> $frecuenciaDePago,
				'inventario'		=> $inventario,
				'comision'			=> $comision
			);
			$this->db->where('idUsuario',$idUsuario);
			$this->db->where('nombreCliente',$nombreCliente);
			$this->db->update('Clientes', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end updateClient

	public function updateContactInfo($params) {
		extract($params);

		if (isset($idContacto) AND $idContacto > 0 AND (isset($nombreCliente) AND strlen($nombreCliente) > 0) AND (isset($nombreContacto) AND strlen($nombreContacto) > 0) AND (isset($puestoContacto) AND strlen($puestoContacto) > 0)) {
			$data_update = array(
				'nombreContacto'	=> $nombreContacto,
				'puestoContacto'	=> $puestoContacto
			);
			$this->db->where('idContacto',$idContacto);
			$this->db->update('Contactos', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end updateContactInfo()

	public function updateContactMail($params) {
		extract($params);

		if (isset($idCorreo) AND $idCorreo > 0 AND (isset($correo) AND strlen($correo) > 0) AND (isset($idContacto) AND $idContacto > 0)) {
			$data_update = array(
				'correo'	=> $correo
			);
			$this->db->where('idCorreo', $idCorreo);
			$this->db->update('Correos', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end updateContactMail()

	public function updateContactTelephone($params) {
		extract($params);

		if (isset($idTelefono) AND $idTelefono > 0 AND (isset($telefono) AND strlen($telefono) > 0)) {
			$data_update = array(
				'telefono'	=> $telefono
			);
			$this->db->where('idTelefono', $idTelefono);
			$this->db->update('Telefonos', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end updateContactTelephone()

	public function changeUserPassword($params) {
		extract($params);

		if (isset($idUsuario) AND $idUsuario > 0 AND (isset($oldPassword) AND strlen($oldPassword) > 0 ) AND (isset($newPassword) AND strlen($newPassword) > 0) AND (isset($mail) AND strlen($mail) > 0)) {
			// Comprobamos que se sabe el viejo password (Seguridad de que es la misma persona);
			if ($oldPassword == getCoPa($params)) {
				$data_update = array(
					'password'	=> $newPassword
				);
				$this->db->where('idUsuario', $idUsuario);
				$this->db->update('Usuarios', $data_update);

				$resultUpdate = $this->db->affected_rows();
				if ($resultUpdate > 0) {
					return true;
				}
				return false;
			}
			return false;
		}
	}

	// get the correct password from the users or null
	private function getCoPa($params) {
		extract($params);

		$res = '';
		if (isset($idUsuario) AND $idUsuario > 0 AND (isset($mail) AND strlen($mail) > 0)) {
			$this->db->select('password');
			$this->db->from('Usuarios');
			$this->db->where('idUsuario',$idUsuario);
			$this->db->where('mail', $mail);

			$aux = $this->db->get();
			$aux_ = $aux->result();
			$res = $aux_[0]->password;
		}
		return res;
	}// end getCoPa()

	public function updateUserInfo($params) {
		extract($params);

		if (isset($nombre) AND strlen($nombre) > 0 AND (isset($mail) AND strlen($mail) > 0) AND (isset($telefono) AND strlen($telefono) > 0) AND (isset($idUsuario) AND $idUsuario > 0)) {
			$data_update = array(
				'nombre'	=> $nombre,
				'mail'		=> $mail,
				'telefono'	=> $telefono
			);
			$this->db->where('idUsuario', $idUsuario);
			$this->db->update('Usuarios', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end updateUserInfo()

	public function updateTarea($params) {
		extract($params);

		if (isset($idTarea) AND $idTarea > 0 AND (isset($tarea) AND strlen($tarea) > 0)) {
			$data_update = array(
				'tarea'	=> $tarea
			);
			$this->db->where('idTarea', $idTarea);
			$this->db->update('Tareas', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
	}// end updateTarea()

	public function updateActividades($params) {
		extract($params);

		if ((isset($idActividad) AND $idActividad > 0) AND (isset($titulo) AND strlen($titulo) > 0)) {
			$data_update = array(
				'titulo'	=> $titulo
			);
			$this->db->where('idActividad', $idActividad);
			$this->db->update('Actividades', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
	}// end updateActividades()

		// end Setters by update

	// end Setters
}
?>