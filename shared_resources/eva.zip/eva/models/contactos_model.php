<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contactos_model extends CI_Model {

	// The default constructor
	function __construct() {
		parent::__construct();
		date_default_timezone_set('America/Mexico_City');
	}

	public function getContactos($params){
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente)) {
			$this->db->select('idContacto, nombreContacto, puestoContacto');
			$this->db->from('Contactos');
			$this->db->where('nombreCliente',$nombreCliente);

			$resultadoClientes = $this->db->get();
			if ($resultadoClientes->num_rows() > 0) {
				$result = $resultadoClientes->result();
			}
		}
		return $result;
	}// end getContactos()

	public function getContactInfo($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($nombreContacto) AND strlen($nombreContacto) > 0)) {
			$this->db->select('C.nombreCliente, M.correo, CT.nombreContacto, CT.puestoContacto, T.telefono');
			$this->db->from('Clientes AS C');
			$this->db->join('Directorio AS D', 'C.nombreCliente = D.nombreCliente', 'inner');
			$this->db->join('Contactos AS CT', 'CT.idContacto = D.idContacto', 'inner');
			$this->db->join('Correos AS M', 'CT.idContacto = M.Contactos_idContacto', 'inner');
			$this->db->join('Telefonos AS T', 'M.idContacto = T.idContacto', 'inner');
			$this->db->where('C.nombreCliente',$nombreCliente);
			$this->db->where('CT.nombreContacto',$nombreContacto);
			/*
			 * Esta consulta trae el siguiente Query
			 * SELECT C.nombreCliente, M.correo, CT.nombreContacto, CT.puestoContacto -- M.correo
			 * 	FROM Clientes AS C
    		 * 	INNER JOIN Directorio AS D 
			 * 		ON C.nombreCliente = D.nombreCliente
			 * 	INNER JOIN Contactos AS CT
			 * 		ON CT.idContacto = D.idContacto
			 * 	INNER JOIN Correos AS M
			 * 		ON CT.idContacto = M.idContacto
			 * INNER JOIN Telefonos AS T
			 * 		ON M.idContacto = T.idContacto
			 * 	WHERE C.nombreCliente = $nombreCliente
    		 * 	AND CT.nombreContacto = $nombreContacto;
			 */

			$correosElectronicos = $this->db->get();
			if ($correosElectronicos->num_rows() > 0) {
				$result = $correosElectronicos->result();
			}
			return $result;
		}else{ //Si la tienda no existe regresamos false
			return false;
		}
	}// end getContactInfo()

	public function createContanct($params) {
		extract($params);

		// Revisamos si el contacto no exite
		$existContact = true;
		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($nombreContacto) AND strlen($nombreContacto) > 0)) {
			$this->db->select('idContacto');
			$this->db->from('Contactos');
			$this->db->where('nombreCliente',$nombreCliente);
			$this->db->where('nombreContacto',$nombreContacto);

			$resContactExist = $this->db->get();
			if ($resContactExist->num_rows() > 0) {
				$existContact = false;
			}
		}

		if ($existContact) {
			if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($nombreContacto) AND strlen($nombreContacto) > 0) AND (isset($puestoContacto) AND strlen($puestoContacto) > 0)) {
				$data_contact = array(
					'nombreCliente'		=> $nombreCliente,
					'nombreContacto'	=> $nombreContacto,
					'puestoContacto'	=> $puestoContacto
				);
				$this->db->insert('Contactos',$data_contact);
				$resultInsert = $this->db->affected_rows();
				if ($resultInsert > 0) {
					// the last id inserted
    				$idContacto = $this->db->insert_id();
    				return $this->asignContactToClient($nombreCliente, $idContacto);
				}
				return false;
			}
			return false;
		}
	}// end createContanct()

	private function asignContactToClient($nombreCliente, $idContacto) {

		if (isset($nombreCliente) AND strlen($nombreCliente) > 0 AND (isset($idContacto) AND $idContacto > 0)) {
			$data_insert = array(
				'nombreCliente'		=> $nombreCliente,
				'idContacto'		=> $idContacto
			);
			$this->db->insert('Directorio', $data_insert);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
		return false;
	}

	public function createContactDataMail($params) {
		extract($params);

		if (isset($correo) AND strlen($correo) > 0 AND (isset($idContacto) AND $idContacto > 0)) {
			$data_contact = array(
				'idContacto'	=> $idContacto,
				'correo'		=> $correo
			);
			$this->db->insert('Correos', $data_contact);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
	}// end createContactDataMail()

	public function createContactDataTelephone($params) {
		extract($params);

		if (isset($telefono) AND strlen($telefono) > 0 AND (isset($idContacto) AND $idContacto > 0)) {
			$data_contact = array(
				'idContacto'	=> $idContacto,
				'telefono'		=> $telefono
			);
			$this->db->insert('Telefonos', $data_contact);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end createContactDataTelephone()

	public function updateContactInfo($params) {
		extract($params);

		if (isset($idContacto) AND $idContacto > 0 AND (isset($nombreCliente) AND strlen($nombreCliente) > 0) AND (isset($nombreContacto) AND strlen($nombreContacto) > 0) AND (isset($puestoContacto) AND strlen($puestoContacto) > 0)) {
			$data_update = array(
				'nombreContacto'	=> $nombreContacto,
				'puestoContacto'	=> $puestoContacto
			);
			$this->db->where('idContacto',$idContacto);
			$this->db->update('Contactos', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end updateContactInfo()

	public function updateContactMail($params) {
		extract($params);

		if (isset($idCorreo) AND $idCorreo > 0 AND (isset($correo) AND strlen($correo) > 0) AND (isset($idContacto) AND $idContacto > 0)) {
			$data_update = array(
				'correo'	=> $correo
			);
			$this->db->where('idCorreo', $idCorreo);
			$this->db->update('Correos', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end updateContactMail()

	public function updateContactTelephone($params) {
		extract($params);

		if (isset($idTelefono) AND $idTelefono > 0 AND (isset($telefono) AND strlen($telefono) > 0)) {
			$data_update = array(
				'telefono'	=> $telefono
			);
			$this->db->where('idTelefono', $idTelefono);
			$this->db->update('Telefonos', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end updateContactTelephone()

}
	/*
	 * Contactos, todos tenemos contactos en todos lados, en nuestas redes sociales, en nuestros celulares, en nuestras agendas electronicas
	 * a algunos de ellos los conocemos, a otros nunca los hemos visto en persona, pero de igual forma los tenemos por una u otra razon; Contactos
	 * everiware, si lo ponemos en una vieja canción seria algo como "Contactos por aquí, contactos por alla, contactos por delate, contactos por 
	 * detras" en otras palabras, siempre hemos vivido con este concepto al cual bautizamos de esta manera con la invención del telefono, (desde el telegrafo
	 * se tenia esta nocion, o mas bien antes de esto, el tener contacto con alguien, cartas, mensajeros... pero el concepto como tal lu usamos hoy día 
	 * se uso así ya que antes la comunicación era inpersonal), me pregunto que seria de nosotros sin nuestros preciados contactos, tal vez volmeriamos 
	 * solo a contactarnos con la gente, despues de todo se supone somos "sociales".
	 */
?>