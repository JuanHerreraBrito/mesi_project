<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Archivos_model extends CI_Model {

	// The default constructor
	function __construct() {
		parent::__construct();
		date_default_timezone_set('America/Mexico_City');
	}

	public function getArchivosCliente($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente)) {
			$this->db->select('A.url, A.idArchivo');
			$this->db->from('Clientes_has_Archivos AS H');
			$this->db->join('Archivos AS A', 'H.idArchivo = A.idArchivo', 'inner');
			$this->db->where('H.nombreCliente',$nombreCliente);

			$resultadoArchivosClientes = $this->db->get();
			if ($resultadoArchivosClientes->num_rows() > 0) {
				$result = $resultadoArchivosClientes->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end getArchivos()

	//Get the url from the Commentary if it take a File.
	public function isFileInComentary($params) {
		extract($params);

		$result = array();
		if (isset($idComentario) AND $idComentario > 0) {
			$this->db->select('A.url');
			$this->db->from('Comentarios_has_Archivos AS H');
			$this->db->join('Archivos AS A', 'H.idArchivo = A.idArchivo', 'inner');
			$this->db->where('H.idComentario',$idComentario);

			$resultadoArchivosComentarios = $this->db->get();
			if ($resultadoArchivosComentarios->num_rows() > 0) {
				$result = $resultadoArchivosComentarios->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end isFileInComentary()

	public function isFileInActivity($params){
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente) AND (isset($idActividad) AND $idActividad > 0)) {
			$this->db->select('A.url');
			$this->db->from('Clientes_has_Actividades_has_Archivos AS H');
			$this->db->join('Archivos AS A', 'H.idArchivo = A.idArchivo', 'inner');
			$this->db->where('H.nombreCliente',$nombreCliente);
			$this->db->where('H.idActividad',$idActividad);

			$resultadoFileInActivity = $this->db->get();
			if ($resultadoFileInActivity->num_rows() > 0) {
				$result = $resultadoFileInActivity->result();
			}
			return $result;
		}else{
			return false;
		}
	}// end isFileInActivity()

	public function uploadFile($params) {
		extract($params);

		if (isset($url) AND strlen($url) > 0 AND (isset($type) AND strlen($type) > 0) AND (isset($args) AND strlen($args) > 0)) {
			$data_upload = array(
				'url'	=> $url
			);
			$idArchivo = 0;
			$this->db->insert('Archivos', $data_upload);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				$idArchivo = $this->db->insert_id();
				$resultInsert = 0;
				switch ($type) {
					case 'activity':
						$json = json_decode($args);
						$data_C_h_A = array(
							'nombreCliente'		=> $json[0]->nombreCliente,
							'idActividad'		=> $json[0]->idActividad,
							'idArchivo'			=> $idArchivo
						);
						$this->db->insert('Clientes_has_Actividades_has_Archivos', $data_C_h_A);
						$resultInsert = $this->db->affected_rows();
						break;
					case 'commentary':
						$json = json_decode($args);
						$data_C_h_A = array(
							'idComentario'		=> $json[0]->idComentario,
							'idArchivo'			=> $idArchivo
						);
						$this->db->insert('Comentarios_has_Archivos', $data_C_h_A);
						$resultInsert = $this->db->affected_rows();
						break;
					case 'client':
						$data_C_h_A = array(
							'nombreCliente'		=> $json[0]->nombreCliente,
							'idArchivo'			=> $idArchivo
						);
						$this->db->insert('Clientes_has_Archivos', $data_C_h_A);
						$resultInsert = $this->db->affected_rows();
						break;
					default:
						
						break;
				}// end switch
				if ($resultInsert > 0) {
					return true;
				}
				return false;
			}
			return false;
		}
	}// end uploadFile()

	/*public function insertFileByCliente($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente) AND (isset($idArchivo) AND $idArchivo > 0)) {
			$data_C_h_A = array(
				'nombreCliente'		=> $nombreCliente,
				'idArchivo'			=> $idArchivo
			);
			$this->db->insert('Clientes_has_Archivos', $data_C_h_A);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return true;
		}
		return true;
	}// end insertFileByCliente

	public function insertFileByActivity($params) {
		extract($params);

		if (isset($nombreCliente) AND strlen($nombreCliente) AND (isset($idArchivo) AND $idArchivo > 0) AND (isset($idActividad) AND $idActividad > 0)) {
			$data_C_h_A = array(
				'nombreCliente'		=> $nombreCliente,
				'idActividad'		=> $idActividad,
				'idArchivo'			=> $idArchivo
			);
			$this->db->insert('Clientes_has_Actividades_has_Archivos', $data_C_h_A);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
	}// end insertFileByCliente

	public function insertFileByCommentary($params) {
		extract($params);

		if (isset($idComentario) AND $idComentario > 0 AND (isset($idArchivo) AND $idArchivo > 0)) {
			$data_C_h_A = array(
				'idComentario'		=> $idComentario,
				'idArchivo'			=> $idArchivo
			);
			$this->db->insert('Comentarios_has_Archivos', $data_C_h_A);
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				return true;
			}
			return false;
		}
	}// end insertFileByCliente*/

	/*
	 * Y mi vida va pasando atravez de los archivos que hay en mi corazón...
	 * La presente frace se me acaba de ocurrir, pero es que algunas veces al acceder a recuerdos y sentimientos pasados es como si 
	 * estuvienemos haciendo un insert. o cargandolos en un BufferReader para acceder a ellos ya sea por un momento, o por un buen rato y con esta
	 * información cargada enriquecemos, o creamos nuevos archivos para que una vez terminado de usar el archivo cargado simplemente lo desechemos
	 * de la memoria hasta que una vez mas lo volvamos a necesitar y lo carguemos de nuevo...
	 */
}
?>