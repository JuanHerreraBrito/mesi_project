<!DOCTYPE html>
<!-- saved from url=(0042)http://capacitacion.nb9.mx/evaV2/base.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>EVA v1</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="UTF-8">
       
        <!-- CSS -->
        <link href="http://capacitacion.nb9.mx/evaV2/css/bootstrap.css" rel="stylesheet" media="screen">
        <link href="http://capacitacion.nb9.mx/evaV2/css/*.css" rel="stylesheet">
        <link href="http://capacitacion.nb9.mx/evaV2/css/icomoon.css" rel="stylesheet">
        <link href="http://capacitacion.nb9.mx/evaV2/css/media-player.css" rel="stylesheet">
        <link href="http://capacitacion.nb9.mx/evaV2/css/file-manager.css" rel="stylesheet">
        <link href="http://capacitacion.nb9.mx/evaV2/css/form.css" rel="stylesheet">
        <link href="http://capacitacion.nb9.mx/evaV2/css/style.css" rel="stylesheet">
        <script type="text/javascript" src="../../../shared_resources_clean/eva/libraries/js/actions.js"></script>

        <style type="text/css">
            .c-block { margin-bottom: 30px; }
			.side-top{
				height: 65px;
			}
			.site-name{
				background-color: #4d3362;
				color: #6ec6ee;
				font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
				font-size: 35px;
				font-weight: lighter;
				padding: 10px 20px;
			}
			.side-menu > li > a{
				color: #fff;
				padding-left: 10px;
				border-radius: 5px 5px 5px 5px;
				-moz-border-radius: 5px 5px 5px 5px;
				-webkit-border-radius: 5px 5px 5px 5px;
				border: 0px solid #000000;
			}
			.side-menu > li > a:hover{
				background-color: #76afcf;
				font-weight: bold;
			}
			.side-menu > li > a > i{
				color: #fff;
			}
			li.inactive > a,
			li.inactive > a > i{
				color: #aaa;
			}
			li.inactive > a:hover,
			li.inactive > a > i:hover{
				color: #aaa;
			}
			.shortcut{
				box-shadow: none;
				border: none;
				background: none;
				width: 60px;
			}
			.media-title{
				font-size: 20px;
				color: #333;
			}
			.img-title{
				width: 45px;
				height: 45px;
			}
			.img-title > i{
				font-size: 45px;
				color: #333;
			}
			.img-subtitle{
				width: 30px;
				height: 30px;
			}
			.img-subtitle > i{
				font-size: 30px;
				color: #333;
			}
			.add-something{
				color: #5D4F73 !important;
			}
			.button-something{
				background: #49385f;
				color: #fff;
				border-radius: 5px 5px 5px 5px;
				-moz-border-radius: 5px 5px 5px 5px;
				-webkit-border-radius: 5px 5px 5px 5px;
			}
			.button-something:hover{
				background: #fff;
				color: #49385f;
				border-radius: 5px 5px 5px 5px;
				-moz-border-radius: 5px 5px 5px 5px;
				-webkit-border-radius: 5px 5px 5px 5px;
			}
			.alert-kichink {
				color: #48385f;
				background-color: #e1dde5;
				padding: 15px 10px;
				border: 1px solid #625375;
				border-radius: 5px 5px 5px 5px;
				-moz-border-radius: 5px 5px 5px 5px;
				-webkit-border-radius: 5px 5px 5px 5px;
			}
			.cont-media{
				padding-top: 15px;
				padding-bottom: 15px;
			}
        </style>
    <style type="text/css">.jqstooltip { position: absolute;left: 0px;top: 0px;visibility: hidden;background: rgb(0, 0, 0) transparent;background-color: rgba(0,0,0,0.6);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";color: white;font: 10px arial, san serif;text-align: left;white-space: nowrap;padding: 5px;border: 1px solid white;z-index: 10000;}.jqsfield { color: white;font: 10px arial, san serif;text-align: left;}</style></head>
     <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
    <script type="text/javascript">
        //$(document).ready(  function(){
            
            var favoritos=  $.get('/api/clients/getClientes');// end ajax call
            //var aux = jQuery.parseJSON(favoritos.responseText);
            for(var some in favoritos){
                //console.log(some);
                if (!jQuery.isEmptyObject(some)) {
                    for(var algo in some){
                        //console.log(algo);
                        if (!jQuery.isEmptyObject(algo)) {
                            for(var asd in algo){
                                console.log(asd);
                            }else{
                                console.log(algo + "______ FALSE");
                            }
                        }
                    }
                }else{
                    console.log(some);
                }
            }
            
    </script>
    
    <body class="mac-os" cz-shortcut-listen="true" style="">
        <!-- Header -->
        <header id="header" class="clearfix site-options">
            <!-- Logo -->
            <a href="http://capacitacion.nb9.mx/evaV2/index.html" class="logo">
            	<img src="./EVA v1_files/logo_kichink.png" alt="" class="" style="max-width: 150px;">
            </a>
               
            <div class="dropdown profile-menu shadowed">
                <a class="dropdown-toggle" data-toggle="dropdown" href="http://capacitacion.nb9.mx/evaV2/base.html#">
                    <img src="./EVA v1_files/avatar.jpg" alt="" class="profile-pic">
                </a>
                <ul class="dropdown-menu pull-right text-right">
                    <li><a href="">Salir</a></li>
                </ul>
            </div>
        </header>
        
        <section id="main" role="main">
            <!-- Left Sidebar -->
            <aside id="leftbar" class="pull-left">
            	<div class="side-top site-name title-inside-left">EVA</div>
                <div class="sidebar-container">
                    <!-- Main Menu -->
                    <ul class="side-menu menu-options shadowed">
                        <li class="inactive">
                            <a href="http://capacitacion.nb9.mx/evaV2/base.html#"><i class="icon-star"></i>Favoritos</a>
                        </li>
                        <?php

                            //echo $this->form_open('../controllers/api');
                            if (count($favoritos) > 0) {
                                foreach ($favoritos as $favorito) {
                                   echo '<li>';
                                    echo '<a href="#"><i class="icon-home"/>'.$favorito->nombreCliente.'</a> ';
                                }
                            }                            
                        ?>
                    </ul>
                    <ul class="side-menu menu-options shadowed">
                    	<li class="divider"></li>
                    </ul>
                    <ul class="side-menu menu-options shadowed">
                    	<li class="input-icon">
                            <input type="text" class="form-control">
                            <span class="add-on">
                                  <i class="icon-search"></i>
                            </span>
                        </li>
                    </ul>
					<ul class="side-menu menu-options shadowed">
                        <?php
                            if (count($clientes) > 0) {
                                foreach ($clientes as $cliente) {
                                    echo '<li class="submenu">';
                                    echo '<a href="#"><i class="icon-users"></i>'.$cliente->nombreCliente.'</a>';
                                    echo '<ul>';
                                    echo '<li><a href="#">Opcion 1</a></li>';
                                    echo '<li><a href="#">Opcion 2</a></li>';
                                    echo '<li><a href="#">Opcion 3</a></li>';
                                    echo '</ul>';
                                    echo '</li>';
                                }
                            }
                        ?>
                        <!--<li class="submenu">
                            <a href=""><i class="icon-users"></i>Baby Creysi</a>
                            <ul>
                                <li><a href="http://capacitacion.nb9.mx/evaV2/base.html#">Opcion 1</a></li>
                                <li><a href="http://capacitacion.nb9.mx/evaV2/base.html#">Opcion 2</a></li>
                                <li><a href="http://capacitacion.nb9.mx/evaV2/base.html#">Opcion 3</a></li>
                            </ul>
                        </li>-->                        
                    </ul>
                </div>
                <span id="leftbar-toggle" class="visible-xs sidebar-toggle">
                     <i class="icon-angle-right"></i>
                </span>
            </aside>
               
            <!-- Right Sidebar -->
            <aside id="rightbar" class="pull-right">
            	<div id="" class="side-top site-options title-inside-right">
                	<div class="dropdown profile-menu shadowed">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="http://capacitacion.nb9.mx/evaV2/base.html#">
                            <img src="./EVA v1_files/avatar.jpg" alt="" class="img-circle" style="max-width: 40px;">
                        </a>
                        <ul class="dropdown-menu text-right">
                            <li><a href="">Salir</a></li>
                        </ul>
                    </div>
                </div>
                <div class="sidebar-container">
                    <div class="shadowed media">
                        <div class="pull-left img-title">
                        	<i class="icon-address-book"></i>
                        </div>
                        <div class="media-body media-title">
                            <strong>Directorio</strong>
                        </div>
                    </div>
                    <?php
                        if (count($contactos) > 0) {
                            foreach ($contactos as $contacto) {
                                echo '<div class="shadowed media">';
                                    echo '<div class="pull-left img-subtitle">';
                                        echo '<i class="icon-user-3"></i>';
                                    echo '</div>';
                                    echo '<div class="media-body">';
                                        echo $contacto->nombreContacto.'<br>';
                                        echo $contacto->correo.'<br>';
                                        echo '<small>telefono </small>'.$contacto->telefono;
                                    echo '</div>';
                                echo '</div>';
                            }
                        }
                    ?>
                    <!--<div class="shadowed media">
                        <div class="pull-left img-subtitle">
                        	<i class="icon-user-3"></i>
                        </div>
                        <div class="media-body">
                            Nombre de la persona<br>
                            email de contacto<br>
                            <small>telefono</small>
                        </div>
                    </div>-->
                    <div class="shadowed media">
                        <div class="pull-left img-subtitle">
                        	<i class="icon-plus add-something"></i>
                        </div>
                        <div class="media-body add-something">
                            <a href="#">Agregar a directorio</a> 
                        </div>
                    </div>
                </div>

                <span id="rightbar-toggle" class="hidden-lg sidebar-toggle">
                     <i class="icon-angle-left"></i>
                </span>
            </aside>
        
            <!-- Content -->
            <section id="content" class="container">
            	<div class="side-top title-inside-center"><img src="./EVA v1_files/logo_kichink.png" alt="" class="" style="max-width: 150px;"></div>
                <header class="p-header">
                    <h2>Nombre Tienda</h2>
                </header>
                <div class="progress">
                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                    	<span class="sr-only">40% Complete (success)</span>
                    </div>
                </div>
                <div class="col-md-12 alert-kichink">
                	<div class="col-md-8">
                    	<h3><i class="icon-clock"></i> Next Steps</h3>
                        <h4><i class="icon-compass"></i> Actividad: <small>Detalle de la actividad</small></h4>
                        <h4><i class="icon-copy"></i> Actividad: <small>Detalle de la actividad</small></h4>
                        <h4><i class="icon-envelop"></i> Actividad: <small>Detalle de la actividad</small></h4>
                        <h4><i class="icon-pushpin"></i> Actividad: <small>Detalle de la actividad</small></h4>
                        <button class="btn btn-gr-gray btn-xs button-something">Nuevo <i class="icon-plus"></i></button>
                    </div>
                    <div class="col-md-4">
                    	<div class="shadowed side-calendar">
                            <div id="sidebar-calendar" class="fc fc-ltr"><table class="fc-header" style="width:100%"><tbody><tr><td class="fc-header-left"><span class="fc-header-title"><h2>October 2014</h2></span></td><td class="fc-header-center"></td><td class="fc-header-right"><span class="fc-button btn btn-sm btn-gr-gray fc-button-prev fc-state-default fc-corner-left" unselectable="on"><span class="fc-text-arrow"><i class="icon-angle-left"></i></span></span><span class="fc-button btn btn-sm btn-gr-gray fc-button-today fc-state-default fc-state-disabled" unselectable="on">Today</span><span class="fc-button btn btn-sm btn-gr-gray fc-button-next fc-state-default fc-corner-right" unselectable="on"><span class="fc-text-arrow"><i class="icon-angle-right"></i></span></span></td></tr></tbody></table><div class="fc-content" style="position: relative;"><div class="fc-view block fc-view-month fc-grid" style="position:relative" unselectable="on"><div class="fc-event-container" style="position:absolute;z-index:8;top:0;left:0"></div><table class="fc-border-separate" cellspacing="0"><thead><tr class="fc-first fc-last"><th class="fc-day-header fc-sun fc-widget-header fc-first" style="width: 43px;">Sun</th><th class="fc-day-header fc-mon fc-widget-header" style="width: 43px;">Mon</th><th class="fc-day-header fc-tue fc-widget-header" style="width: 43px;">Tue</th><th class="fc-day-header fc-wed fc-widget-header" style="width: 43px;">Wed</th><th class="fc-day-header fc-thu fc-widget-header" style="width: 43px;">Thu</th><th class="fc-day-header fc-fri fc-widget-header" style="width: 43px;">Fri</th><th class="fc-day-header fc-sat fc-widget-header fc-last">Sat</th></tr></thead><tbody><tr class="fc-week fc-first"><td class="fc-day fc-sun fc-widget-content fc-other-month fc-past fc-first" data-date="2014-09-28"><div style="min-height: 29px;"><div class="fc-day-number">28</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-other-month fc-past" data-date="2014-09-29"><div><div class="fc-day-number">29</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-other-month fc-past" data-date="2014-09-30"><div><div class="fc-day-number">30</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-past" data-date="2014-10-01"><div><div class="fc-day-number">1</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-past" data-date="2014-10-02"><div><div class="fc-day-number">2</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-past" data-date="2014-10-03"><div><div class="fc-day-number">3</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-past fc-last" data-date="2014-10-04"><div><div class="fc-day-number">4</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr><tr class="fc-week"><td class="fc-day fc-sun fc-widget-content fc-past fc-first" data-date="2014-10-05"><div style="min-height: 29px;"><div class="fc-day-number">5</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-past" data-date="2014-10-06"><div><div class="fc-day-number">6</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-past" data-date="2014-10-07"><div><div class="fc-day-number">7</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-past" data-date="2014-10-08"><div><div class="fc-day-number">8</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-past" data-date="2014-10-09"><div><div class="fc-day-number">9</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-past" data-date="2014-10-10"><div><div class="fc-day-number">10</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-past fc-last" data-date="2014-10-11"><div><div class="fc-day-number">11</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr><tr class="fc-week"><td class="fc-day fc-sun fc-widget-content fc-past fc-first" data-date="2014-10-12"><div style="min-height: 29px;"><div class="fc-day-number">12</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-past" data-date="2014-10-13"><div><div class="fc-day-number">13</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-past" data-date="2014-10-14"><div><div class="fc-day-number">14</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-past" data-date="2014-10-15"><div><div class="fc-day-number">15</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-past" data-date="2014-10-16"><div><div class="fc-day-number">16</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-past" data-date="2014-10-17"><div><div class="fc-day-number">17</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-past fc-last" data-date="2014-10-18"><div><div class="fc-day-number">18</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr><tr class="fc-week"><td class="fc-day fc-sun fc-widget-content fc-past fc-first" data-date="2014-10-19"><div style="min-height: 29px;"><div class="fc-day-number">19</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-today fc-state-highlight" data-date="2014-10-20"><div><div class="fc-day-number">20</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-future" data-date="2014-10-21"><div><div class="fc-day-number">21</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-future" data-date="2014-10-22"><div><div class="fc-day-number">22</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-future" data-date="2014-10-23"><div><div class="fc-day-number">23</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-future" data-date="2014-10-24"><div><div class="fc-day-number">24</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-future fc-last" data-date="2014-10-25"><div><div class="fc-day-number">25</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr><tr class="fc-week"><td class="fc-day fc-sun fc-widget-content fc-future fc-first" data-date="2014-10-26"><div style="min-height: 29px;"><div class="fc-day-number">26</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-future" data-date="2014-10-27"><div><div class="fc-day-number">27</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-future" data-date="2014-10-28"><div><div class="fc-day-number">28</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-future" data-date="2014-10-29"><div><div class="fc-day-number">29</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-future" data-date="2014-10-30"><div><div class="fc-day-number">30</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-future" data-date="2014-10-31"><div><div class="fc-day-number">31</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-other-month fc-future fc-last" data-date="2014-11-01"><div><div class="fc-day-number">1</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr><tr class="fc-week fc-last"><td class="fc-day fc-sun fc-widget-content fc-other-month fc-future fc-first" data-date="2014-11-02"><div style="min-height: 29px;"><div class="fc-day-number">2</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-other-month fc-future" data-date="2014-11-03"><div><div class="fc-day-number">3</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-other-month fc-future" data-date="2014-11-04"><div><div class="fc-day-number">4</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-other-month fc-future" data-date="2014-11-05"><div><div class="fc-day-number">5</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-other-month fc-future" data-date="2014-11-06"><div><div class="fc-day-number">6</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-other-month fc-future" data-date="2014-11-07"><div><div class="fc-day-number">7</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-other-month fc-future fc-last" data-date="2014-11-08"><div><div class="fc-day-number">8</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr></tbody></table></div></div></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12" style="padding-top: 30px; padding-bottom: 20px;">
                </div>
                <?php
                    if (count($comentarios) > 0) {
                        foreach ($comentarios as $comentario) {
                            echo '<div class="col-md-12 cont-media">';
                            echo '<div class="media">';
                                echo '<div class="media-body">';
                                    echo '<div class="media-header">';
                                        echo '<span class="poster">';
                                            echo '<a href="#">'.$comentario->nombre.'</a>';
                                        echo '</span>';
                                    echo '</div>';
                                    echo '<p>'.$comentario->comentario.'</p>';
                                    echo '<span class="post-time">';
                                        echo '<i class="icon-clock"></i>';
                                        echo $comentario->fechaEnvio;
                                    echo '</span>';
                                echo '</div>';
                            echo '</div>';
                            echo '</div>';
                        }
                    }
                ?>
                <!--<div class="col-md-12 cont-media">
                    <div class="media">
                        <a class="pull-left" href="http://capacitacion.nb9.mx/evaV2/base.html#">
                            <img src="./EVA v1_files/avatar.jpg" alt="" class="media-object img-circle">
                        </a>
                        <div class="media-body">
                            <div class="media-header">
                                <span class="poster">
                                    <a href="http://capacitacion.nb9.mx/evaV2/base.html#">Claudio</a>
                                </span>
                            </div>
                            <p>Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.</p>
                            <span class="post-time">
                                    <i class="icon-clock"></i>
                                    10 Octubre 2:50 pm
                                </span>
                                <a href="" class="post-reply">
                                    <i class="icon-reply"></i>
                                    Reply
                                </a>
                        </div>
                    </div>
                </div>-->
                <div class="post-area">
                    <div class="posting">
                        <textarea class="text-post" placeholder="Comenta"></textarea>
                        <div class="post-options"> <!-- Aqui se añaden los metodos para subir archibos, no importa de que tipo, o si se quiere hacer la comprovación se hace del lado de js (permito subir lo que sea, o restrinjo ciertos tipos de archivos, .exe, .bat, .sh, .dll, etc...) -->
                            <a href="#" data-toggle="tooltip" data-original-title="Imagen" class="ttips"><i class="icon-image"></i></a>
                            <a href="http://capacitacion.nb9.mx/evaV2/base.html#" data-toggle="tooltip" data-original-title="Vinculo" class="ttips"><i class="icon-link"></i></a>
                            <a href="http://capacitacion.nb9.mx/evaV2/base.html#" data-toggle="tooltip" data-original-title="Archivo" class="ttips"><i class="icon-copy-3"></i></a>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </section>
        </section>
        <!--
        <footer id="footer">
            <p>Copyright (c) 2014, Kichink by PablitoNoguez.</p>
        </footer>
        -->
        <!-- Javascipt -->
        <script src="./EVA v1_files/jquery-1.10.2.min.js"></script>
        <script src="./EVA v1_files/jquery-ui-1.10.3.min.js"></script>
        <script src="./EVA v1_files/bootstrap.min.js"></script>
        <script src="./EVA v1_files/feeds.js"></script>
        <script src="./EVA v1_files/chosen.js"></script>
        <script src="./EVA v1_files/shadowbox.js"></script>
        <script src="./EVA v1_files/sparkline.min.js"></script>
        <script src="./EVA v1_files/masonry.min.js"></script>
        <script src="./EVA v1_files/enscroll.min.js"></script>
        <script src="./EVA v1_files/calendar.min.js"></script>
        <script src="./EVA v1_files/datatables.min.js"></script>
        <script src="./EVA v1_files/autosize.min.js"></script>
        <script src="./EVA v1_files/select.min.js"></script>
        <script src="./EVA v1_files/toggler.min.js"></script>
        <script src="./EVA v1_files/datetimepicker.min.js"></script>
        <script src="./EVA v1_files/colorpicker.min.js"></script>
        <script src="./EVA v1_files/fileupload.min.js"></script>
        <script src="./EVA v1_files/media-player.js"></script>
        <script src="./EVA v1_files/validate.min.js"></script>
        <script src="./EVA v1_files/validationEngine.min.js"></script>
        <script src="./EVA v1_files/functions.js"></script>
    

        <textarea style="position: absolute; top: -999px; left: 0px; right: auto; bottom: auto; border: 0px; box-sizing: content-box; word-wrap: break-word; overflow: hidden; -webkit-transition: none; transition: none; height: 0px !important; min-height: 0px !important;"></textarea><div id="sb-container"><div id="sb-overlay"><a id="sb-nav-close" title="" onclick="Shadowbox.close()"><i class="icon-close"></i></a></div><div id="sb-wrapper"><div id="sb-title"><div id="sb-title-inner" class="text-center"></div></div><div id="sb-wrapper-inner"><div id="sb-body"><div id="sb-body-inner"></div><div id="sb-loading"><div id="sb-loading-inner"><img src="./EVA v1_files/loader.gif" alt=""></div></div></div></div><div id="sb-info"><div id="sb-info-inner"><div id="sb-nav"><div id="sb-counter"></div><a id="sb-nav-previous" title="" onclick="Shadowbox.previous()"><i class="icon-arrow-left-2"></i></a><a id="sb-nav-next" title="" onclick="Shadowbox.next()"><i class="icon-arrow-right-2"></i></a><a id="sb-nav-play" title="" onclick="Shadowbox.play()"><i class="icon-play-3"></i></a><a id="sb-nav-pause" title="" onclick="Shadowbox.pause()"><i class="icon-pause-2"></i></a></div></div></div></div></div></body></html>