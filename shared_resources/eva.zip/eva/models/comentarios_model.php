<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Comentarios_model extends CI_Model {

	// The default constructor
	function __construct() {
		parent::__construct();
		date_default_timezone_set('America/Mexico_City');
	}

	public function getComentarios($params) {
		extract($params);

		$result = array();
		if (isset($nombreCliente) AND strlen($nombreCliente)) {
			if (isset($numComentInit) AND $numComentInit >= 0 AND (isset($numComentEnd) AND $numComentEnd > $numComentInit)) {
				$this->db->select('U.nombre, C.comentario, C.fechaEnvio, C.idComentario');
				$this->db->from('Clientes_has_Comentarios AS H');
				$this->db->join('Comentarios AS C', 'H.idComentario = C.idComentario', 'inner');
				$this->db->join('Usuarios AS U', 'U.idUsuario = H.idUsuario', 'inner');
				$this->db->where('H.nombreCliente',$nombreCliente);
				$this->db->limit($numComentEnd, $numComentInit);

				$commentaries = $this->db->get();
				if ($commentaries->num_rows() > 0) {
					$result = $commentaries->result();
				}
			}else{
				$this->db->select('U.nombre, C.comentario, C.fechaEnvio');
				$this->db->from('Clientes_has_Comentarios AS H');
				$this->db->join('Comentarios AS C', 'H.idComentario = C.idComentario', 'inner');
				$this->db->join('Usuarios AS U', 'U.idUsuario = H.idUsuario', 'inner');
				$this->db->where('H.nombreCliente',$nombreCliente);
				$this->db->limit(3);

				$commentaries = $this->db->get();
				if ($commentaries->num_rows() > 0) {
					$result = $commentaries->result();
				}
			}
			return $result;
		}else{
			return false;
		}
	}// end getComentaios()

	public function createCommentary($params) {
		extract($params);

		if (isset($comentario) AND strlen($comentario) > 0 AND (isset($idUsuario) AND $idUsuario > 0) AND (isset($nombreCliente) AND strlen($nombreCliente) > 0)) {
			$data_commentary = array(
				'comentario'	=> $comentario,
				'fechaEnvio'	=> date('Y-m-d H:i:s')
			);
			$this->db->insert('Comentarios', $data_commentary);
			$insertComment = false;
			$resultInsert = $this->db->affected_rows();
			if ($resultInsert > 0) {
				$insertComment = true;
			}
			if ($insertComment) {

				// the last id inserted
    			$idCommentary = $this->db->insert_id();
				$data_C_h_C = array(
					'nombreCliente'		=> $nombreCliente,
					'idComentario'		=> $idCommentary,
					'idUsuario'			=> $idUsuario
				);
				$this->db->insert('Clientes_has_Comentarios', $data_C_h_C);
				$resultInsert = $this->db->affected_rows();
				if ($resultInsert > 0) {
					return true;
				}
				return false;
			}
			return false;
		}// end if
	}// end createCommentary();

}
	/*
	 * Comentarios....
	 * Siempre estamos comentando todo, emitimos comentarios todo el tiempo aunque no los lleguemos a expresar siempre tenemos una opinion al respecto de 
	 * muchas cosas, desde el simple echo de si nos gusta un color, un olor, vamos emitiendo y dejado nuestra opinion por todos lados
	 * (por ejemplo en este utopico archivo llamado comentarios, y dejando un comentario en los comentarios).
	 * Siempre hacemos lo mismo, despues de todo es una de las partes que nos hacen unicos como individuis, el conjunto de comentarios que emitimos sobre todo.
	 */
?>