<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Usuarios_model extends CI_Model {

	// The default constructor
	function __construct() {
		parent::__construct();
		date_default_timezone_set('America/Mexico_City');
	}

	// Get the name, email, and phone from the user using the idUsuario.
	public function getDataUser($params) {
		extract($params);

		$result = array();
		if (isset($idUsuario) AND $idUsuario > 0) {
			$this->db->select('nombre, mail, telefono');
			$this->db->from('Usuarios');
			$this->db->where('idUsuario',$idUsuario);

			$resultUsers = $this->db->get();
			if ($resultUsers->num_rows() > 0) {
				$result = $resultUsers->result();
			}
		}
		return $result;
	}// end getDataUser()

	public function createUser($params) {
		extract($params);

		// Revisamos que el usuario no exista de acuerdo a su correo electronico
		if ($this->existUser($params)) {
			if ((isset($nombre) AND strlen($nombre) > 0) AND (isset($password) AND strlen($password) > 0) AND (isset($mail) AND strlen($mail) > 0) AND (isset($telefono) AND strlen($telefono) > 0)) {
				$data_user = array(
					'nombre'		=> $nombre,
					'password'		=> $password,
					'mail'			=> $mail,
					'telefono'		=> $telefono
				);
				$this->db->insert('Usuarios', $data_user);
				$resultInsert = $this->db->affected_rows();
				if ($resultInsert > 0) {
					return true;
				}
				return false;
			}// end if
		}// end if
		return false;
	}// end createUser()

	private function existUser($params) {
		extract($params);

		$result = true;
		if (isset($mail) AND strlen($mail) > 0) {
			$this->db->select('idUsuario');
			$this->db->from('Usuarios');
			$this->db->where('mail',$mail);

			$aux = $this->db->get();
			if ($aux->num_rows() > 0) {
				$result = false;
			}
		}
		return $result;
	}// end existUser()

	public function changeUserPassword($params) {
		extract($params);

		if (isset($idUsuario) AND $idUsuario > 0 AND (isset($oldPassword) AND strlen($oldPassword) > 0 ) AND (isset($newPassword) AND strlen($newPassword) > 0) AND (isset($mail) AND strlen($mail) > 0)) {
			// Comprobamos que se sabe el viejo password (Seguridad de que es la misma persona);
			if ($oldPassword == getCoPa($params)) {
				$data_update = array(
					'password'	=> $newPassword
				);
				$this->db->where('idUsuario', $idUsuario);
				$this->db->update('Usuarios', $data_update);

				$resultUpdate = $this->db->affected_rows();
				if ($resultUpdate > 0) {
					return true;
				}
				return false;
			}
			return false;
		}
	}

	// get the correct password from the users or null
	private function getCoPa($params) {
		extract($params);

		$res = '';
		if (isset($idUsuario) AND $idUsuario > 0 AND (isset($mail) AND strlen($mail) > 0)) {
			$this->db->select('password');
			$this->db->from('Usuarios');
			$this->db->where('idUsuario',$idUsuario);
			$this->db->where('mail', $mail);

			$aux = $this->db->get();
			$aux_ = $aux->result();
			$res = $aux_[0]->password;
		}
		return res;
	}// end getCoPa()

	public function updateUserInfo($params) {
		extract($params);

		if (isset($nombre) AND strlen($nombre) > 0 AND (isset($mail) AND strlen($mail) > 0) AND (isset($telefono) AND strlen($telefono) > 0) AND (isset($idUsuario) AND $idUsuario > 0)) {
			$data_update = array(
				'nombre'	=> $nombre,
				'mail'		=> $mail,
				'telefono'	=> $telefono
			);
			$this->db->where('idUsuario', $idUsuario);
			$this->db->update('Usuarios', $data_update);

			$resultUpdate = $this->db->affected_rows();
			if ($resultUpdate > 0) {
				return true;
			}
			return false;
		}
		return false;
	}// end updateUserInfo()
}
	/*
	 * Usuarios, todos alguna vez llegamos a confiar en ellos de una manera u otra, y de una manera u otra todos somos 
	 * usuarios de algo, por ejemplo si tienes auto propio eres un usuario de autos a estos los llaman automovilistas,
	 * o si usas el transporte publico te vuelves usuario de este medio, la televisión, el celular, en fin cualquier 
	 * herramienta de la que tengamos disposicion y hagamos uso nos vuelve automaticamente usuarios de ella, la unica 
	 * pregunta seria como calsificamos a los usuarios...
	 * Yo lo haria en dos caregorias las cuales se pueden sub categorizar de distintas maneras.
	 * 	La primera seria usuarios por defecto, o por pstron, a duras penas perciven que hacen uso de algo, de alguna
	 * tecnología u artefacto, por lo tal no se consideran usuarios de ello, generalmente son personas remisas y calladas
	 * que tienden a no encajar bien en la sociedad, o encajar demasiado bien...+
	 * 	La segunda categorización que haria serian usuarios autoctonos y orgullosos de lo que usan. A tal grado que llegan
	 * a convencer a otros usuarios mas defortunados que los productos usados son la ultima maravilla; Generalmente este 
	 * tipo de usuarios se caracteriza por usar Windows o Mac.
	 * :)
	 */
?>